# Change Log

## Summary
- **Issue**: 项目配置页「重置为系统默认」对 `git` 节点（及其他嵌套字段）不生效
- **Root cause**: `buildDefaultsFromGlobal` 函数的参数类型只声明了 4 个顶层 scalar 字段，
  `git`、`claude_md`、`models`、`execution_context_*`、`validation`（完整字段）、
  `architect_prompt`、`engineer_prompt` 均未从全局配置继承，而是使用了硬编码的静态值。
  重置时写入的 `git: { enabled: false }` 与系统配置中实际的 git 设置无关。

## File Manifest

### Modified
- `src/pages/projects/ProjectConfigPage.tsx`
  - `buildDefaultsFromGlobal` 入参类型由局部匿名对象（4字段）改为完整的 `GlobalConfig`
  - 函数体内所有嵌套字段均从 global 继承，含：
    - `git`：直接使用 `global.git ?? { enabled: false }`
    - `claude_md`：逐字段继承，含 `enabled / model / memory_model`
    - `models`：直接使用 `global.models ?? {}`
    - `validation`：补全 `model / step_filter / stdout_preview_limit / target_coverage` 的继承
    - `architect_prompt / engineer_prompt`：继承全局提示词
    - `execution_context_max_turns / execution_context_content_limit`：继承全局值

## How to Apply
```
unzip -o changes.zip -d <项目根目录>
```
覆盖后无需其他手动操作，热重载或重新构建即生效。
